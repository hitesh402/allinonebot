export const name = "ready";
export const once = true;
export async function execute(client) {
  console.log(`✅ Logged in as ${client.user.tag}`);
  try {
    client.user.setActivity({ name: "/help | All-in-one Bot", type: 0 });
  } catch {}
}
