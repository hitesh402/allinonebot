export const name = "interactionCreate";
export const once = false;
export async function execute(interaction, client) {
  if (!interaction.isChatInputCommand()) return;

  const cmd = client.commands.get(interaction.commandName);
  if (!cmd) return await interaction.reply({ content: "Command not found.", ephemeral: true });

  try {
    await cmd.execute(interaction, client);
  } catch (err) {
    console.error("Command error:", err);
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ content: "There was an error running that command.", ephemeral: true });
    } else {
      await interaction.reply({ content: "There was an error running that command.", ephemeral: true });
    }
  }
}
