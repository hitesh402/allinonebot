# All-in-One Discord Bot

## Setup (on your VPS)
1. Copy `.env.example` to `.env` and fill in your keys.
2. `npm install`
3. `node deploy-commands.js`  # registers guild commands (instant)
4. `node index.js` or `pm2 start index.js`

## Notes
- This project uses Guild commands by default (fast updates).
- Fill `.env` with your BOT TOKEN, CLIENT_ID, GUILD_ID and OPENAI_API_KEY if you want AI features.
