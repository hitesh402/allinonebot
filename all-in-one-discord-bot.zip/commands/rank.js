import { SlashCommandBuilder } from "discord.js";
import db from "../utils/database.js";

export const data = new SlashCommandBuilder()
  .setName("rank")
  .setDescription("Show your level and XP");

export async function execute(interaction) {
  const id = interaction.user.id;
  const row = db.prepare("SELECT xp, level FROM levels WHERE user_id = ?").get(id);
  const xp = row ? row.xp : 0;
  const level = row ? row.level : 1;
  await interaction.reply({ content: `Level: ${level} | XP: ${xp}`, ephemeral: false });
}
