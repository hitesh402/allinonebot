import { SlashCommandBuilder, PermissionsBitField } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("kick")
  .setDescription("Kick a member")
  .addUserOption(o => o.setName("target").setDescription("User to kick").setRequired(true))
  .addStringOption(o => o.setName("reason").setDescription("Reason"));

export async function execute(interaction) {
  if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers)) return interaction.reply({ content: "Missing KickMembers permission.", ephemeral: true });
  const target = interaction.options.getUser("target");
  const reason = interaction.options.getString("reason") || "No reason";
  const member = await interaction.guild.members.fetch(target.id).catch(()=>null);
  if (!member) return interaction.reply({ content: "Member not found.", ephemeral: true });
  await member.kick(reason);
  await interaction.reply({ content: `Kicked ${target.tag} — ${reason}` });
}
