import { SlashCommandBuilder } from "discord.js";
import ytdl from "ytdl-core";
import { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, getVoiceConnection } from "@discordjs/voice";

const queues = new Map();

export const data = new SlashCommandBuilder()
  .setName("play")
  .setDescription("Play a YouTube URL in voice channel")
  .addStringOption(o => o.setName("query").setDescription("YouTube URL").setRequired(true));

export async function execute(interaction) {
  const url = interaction.options.getString("query");
  const member = interaction.member;
  const voiceChannel = member.voice.channel;
  if (!voiceChannel) return interaction.reply({ content: "You must be in a voice channel.", ephemeral: true });
  if (!ytdl.validateURL(url)) return interaction.reply({ content: "Invalid YouTube URL.", ephemeral: true });

  const guildId = interaction.guildId;
  if (!queues.has(guildId)) queues.set(guildId, []);
  const queue = queues.get(guildId);
  queue.push(url);
  await interaction.reply({ content: `Added to queue. Position: ${queue.length}`, ephemeral: false });

  // if not playing, start
  if (queue.length === 1) {
    const connection = joinVoiceChannel({
      channelId: voiceChannel.id,
      guildId: guildId,
      adapterCreator: interaction.guild.voiceAdapterCreator
    });
    const player = createAudioPlayer();
    const playNext = async () => {
      const next = queue[0];
      if (!next) {
        connection.destroy();
        queues.delete(guildId);
        return;
      }
      const stream = ytdl(next, { filter: 'audioonly', highWaterMark: 1<<25 });
      const resource = createAudioResource(stream);
      player.play(resource);
      connection.subscribe(player);

      player.on(AudioPlayerStatus.Idle, () => {
        queue.shift();
        playNext();
      });
    };
    playNext();
  }
}
