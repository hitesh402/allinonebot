import { SlashCommandBuilder } from "discord.js";
import fetch from "node-fetch";

export const data = new SlashCommandBuilder()
  .setName("ask")
  .setDescription("Ask the AI (OpenAI GPT)")
  .addStringOption(o => o.setName("prompt").setDescription("Question to ask").setRequired(true));

export async function execute(interaction) {
  const prompt = interaction.options.getString("prompt");
  await interaction.deferReply();
  if (!process.env.OPENAI_API_KEY) return interaction.editReply("OpenAI API key not set in .env");

  try {
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 600
      })
    });
    const data = await res.json();
    const answer = data.choices?.[0]?.message?.content || "No response.";
    await interaction.editReply(answer);
  } catch (err) {
    console.error("OpenAI error:", err);
    await interaction.editReply("Error contacting OpenAI.");
  }
}
