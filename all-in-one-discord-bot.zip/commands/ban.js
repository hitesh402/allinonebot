import { SlashCommandBuilder, PermissionsBitField } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("ban")
  .setDescription("Ban a member")
  .addUserOption(o => o.setName("target").setDescription("User to ban").setRequired(true))
  .addStringOption(o => o.setName("reason").setDescription("Reason"));

export async function execute(interaction) {
  if (!interaction.member.permissions.has(PermissionsBitField.Flags.BanMembers)) return interaction.reply({ content: "Missing BanMembers permission.", ephemeral: true });
  const target = interaction.options.getUser("target");
  const reason = interaction.options.getString("reason") || "No reason";
  const member = await interaction.guild.members.fetch(target.id).catch(()=>null);
  if (!member) return interaction.reply({ content: "Member not found.", ephemeral: true });
  await member.ban({ reason });
  await interaction.reply({ content: `Banned ${target.tag} — ${reason}` });
}
