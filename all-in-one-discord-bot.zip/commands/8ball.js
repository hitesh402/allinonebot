import { SlashCommandBuilder } from "discord.js";

const answers = ["Yes", "No", "Maybe", "Ask later", "Definitely", "I don't think so"];

export const data = new SlashCommandBuilder()
  .setName("8ball")
  .setDescription("Ask the magic 8ball")
  .addStringOption(o => o.setName("question").setDescription("Your question").setRequired(true));

export async function execute(interaction) {
  const ans = answers[Math.floor(Math.random()*answers.length)];
  await interaction.reply({ content: ans, ephemeral: false });
}
