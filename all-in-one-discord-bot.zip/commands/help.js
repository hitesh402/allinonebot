import { SlashCommandBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("help")
  .setDescription("List available commands");

export async function execute(interaction) {
  const lines = [
    "**Core:** /help, /ping, /serverinfo, /userinfo",
    "**Moderation:** /ban, /kick, /mute, /clear",
    "**AI:** /ask",
    "**Music:** /play, /skip, /stop, /pause, /resume",
    "**Economy:** /balance, /daily, /work",
    "**Leveling:** /rank",
    "**Fun:** /8ball, /meme"
  ];
  await interaction.reply({ content: lines.join("\n"), ephemeral: true });
}
