import { SlashCommandBuilder } from "discord.js";
import db from "../utils/database.js";

export const data = new SlashCommandBuilder()
  .setName("balance")
  .setDescription("Show your balance");

export async function execute(interaction) {
  const id = interaction.user.id;
  const row = db.prepare("SELECT balance FROM economy WHERE user_id = ?").get(id);
  const bal = row ? row.balance : 0;
  await interaction.reply({ content: `Your balance: ${bal}`, ephemeral: false });
}
