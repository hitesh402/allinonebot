import { SlashCommandBuilder, PermissionsBitField } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("clear")
  .setDescription("Bulk delete messages (max 100)")
  .addIntegerOption(o => o.setName("amount").setDescription("Number of messages").setRequired(true));

export async function execute(interaction) {
  if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) return interaction.reply({ content: "You need Manage Messages permission.", ephemeral: true });
  const amt = interaction.options.getInteger("amount");
  if (amt < 1 || amt > 100) return interaction.reply({ content: "Amount must be 1-100.", ephemeral: true });
  const messages = await interaction.channel.bulkDelete(amt, true);
  await interaction.reply({ content: `Deleted ${messages.size} messages.`, ephemeral: true });
}
