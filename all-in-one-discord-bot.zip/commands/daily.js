import { SlashCommandBuilder } from "discord.js";
import db from "../utils/database.js";

export const data = new SlashCommandBuilder()
  .setName("daily")
  .setDescription("Claim daily coins");

export async function execute(interaction) {
  const id = interaction.user.id;
  const now = Date.now();
  const row = db.prepare("SELECT last_daily, balance FROM economy WHERE user_id = ?").get(id);
  if (row && now - row.last_daily < 24*60*60*1000) {
    return interaction.reply({ content: "You already claimed today.", ephemeral: true });
  }
  if (!row) {
    db.prepare("INSERT INTO economy (user_id, balance, last_daily) VALUES (?, ?, ?)").run(id, 100, now);
  } else {
    db.prepare("UPDATE economy SET balance = balance + 100, last_daily = ? WHERE user_id = ?").run(now, id);
  }
  await interaction.reply({ content: "You claimed 100 coins!", ephemeral: false });
}
