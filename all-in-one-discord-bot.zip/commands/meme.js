import { SlashCommandBuilder } from "discord.js";
import fetch from "node-fetch";

export const data = new SlashCommandBuilder()
  .setName("meme")
  .setDescription("Get a random meme");

export async function execute(interaction) {
  await interaction.deferReply();
  try {
    const res = await fetch("https://meme-api.com/gimme");
    const j = await res.json();
    await interaction.editReply({ content: j.url });
  } catch (err) {
    await interaction.editReply("Couldn't fetch meme.");
  }
}
