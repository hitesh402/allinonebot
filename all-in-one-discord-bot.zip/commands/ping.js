import { SlashCommandBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("ping")
  .setDescription("Replies with Pong!");

export async function execute(interaction) {
  const sent = await interaction.reply({ content: "Pinging...", fetchReply: true });
  const diff = sent.createdTimestamp - interaction.createdTimestamp;
  await interaction.editReply(`🏓 Pong! Roundtrip: ${diff}ms`);
}
