import { SlashCommandBuilder, PermissionsBitField } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("mute")
  .setDescription("Mute a member (adds 'Muted' role, create role if needed)")
  .addUserOption(o => o.setName("target").setDescription("User to mute").setRequired(true));

export async function execute(interaction) {
  if (!interaction.member.permissions.has(PermissionsBitField.Flags.ModerateMembers) && !interaction.member.permissions.has(PermissionsBitField.Flags.ManageRoles))
    return interaction.reply({ content: "Missing permissions.", ephemeral: true });

  const target = interaction.options.getUser("target");
  const member = await interaction.guild.members.fetch(target.id).catch(()=>null);
  if (!member) return interaction.reply({ content: "Member not found.", ephemeral: true });

  let role = interaction.guild.roles.cache.find(r => r.name === "Muted");
  if (!role) {
    role = await interaction.guild.roles.create({ name: "Muted", reason: "Create Muted role for mutes" });
    for (const [chId, ch] of interaction.guild.channels.cache) {
      try {
        await ch.permissionOverwrites.edit(role, { SendMessages: false, AddReactions: false, Speak: false });
      } catch {}
    }
  }

  await member.roles.add(role);
  await interaction.reply({ content: `${target.tag} has been muted.`, ephemeral: false });
}
