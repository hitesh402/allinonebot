import { SlashCommandBuilder } from "discord.js";
import { getVoiceConnection } from "@discordjs/voice";

export const data = new SlashCommandBuilder()
  .setName("skip")
  .setDescription("Skip current track");

export async function execute(interaction) {
  const conn = getVoiceConnection(interaction.guildId);
  if (!conn) return interaction.reply({ content: "Not playing.", ephemeral: true });
  // simplest approach: destroy connection to force next track
  conn.destroy();
  await interaction.reply({ content: "Skipped.", ephemeral: true });
}
