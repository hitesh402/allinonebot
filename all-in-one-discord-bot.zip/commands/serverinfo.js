import { SlashCommandBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("serverinfo")
  .setDescription("Shows server information");

export async function execute(interaction) {
  const g = interaction.guild;
  await interaction.reply({
    content: `**${g.name}**\nID: ${g.id}\nMembers: ${g.memberCount}\nOwner: <@${g.ownerId}>`,
    ephemeral: false
  });
}
