import { SlashCommandBuilder } from "discord.js";
import db from "../utils/database.js";

export const data = new SlashCommandBuilder()
  .setName("work")
  .setDescription("Work to earn coins");

export async function execute(interaction) {
  const id = interaction.user.id;
  const earn = Math.floor(Math.random()*100) + 10;
  const row = db.prepare("SELECT balance FROM economy WHERE user_id = ?").get(id);
  if (!row) {
    db.prepare("INSERT INTO economy (user_id, balance) VALUES (?, ?)").run(id, earn);
  } else {
    db.prepare("UPDATE economy SET balance = balance + ? WHERE user_id = ?").run(earn, id);
  }
  await interaction.reply({ content: `You worked and earned ${earn} coins!`, ephemeral: false });
}
