import { SlashCommandBuilder } from "discord.js";
import { getVoiceConnection } from "@discordjs/voice";

export const data = new SlashCommandBuilder()
  .setName("stop")
  .setDescription("Stop playback and clear queue");

export async function execute(interaction) {
  const conn = getVoiceConnection(interaction.guildId);
  if (conn) {
    conn.destroy();
    await interaction.reply({ content: "Stopped playback.", ephemeral: true });
  } else {
    await interaction.reply({ content: "Not playing.", ephemeral: true });
  }
}
