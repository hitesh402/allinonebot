import { SlashCommandBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("userinfo")
  .setDescription("Shows info about a user")
  .addUserOption(opt => opt.setName("user").setDescription("User to look up"));

export async function execute(interaction) {
  const user = interaction.options.getUser("user") || interaction.user;
  await interaction.reply({ content: `User: ${user.tag}\nID: ${user.id}`, ephemeral: false });
}
